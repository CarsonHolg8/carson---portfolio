document.addEventListener('DOMContentLoaded',function(){
  console.log('Portfolio loaded');
});